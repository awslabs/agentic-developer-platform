#!/usr/bin/env bash
# Called by the native release workflow after its server-authorized job guard.
# Keep the adapter's renderer dependencies out of the gateway and host Python.
set -euo pipefail
[[ $# == 1 && "$1" =~ ^(publish|apply|verify|configure|receipt|foundation)$ ]] || {
  echo 'Usage: modules/tools/adapters/deploy.sh publish|apply|verify|configure|receipt|foundation' >&2
  exit 2
}
adapter_root=$(cd "$(dirname "$0")" && pwd)
umask 077
adapter_temp=$(mktemp -d "${RUNNER_TEMP:-/tmp}/adp-adapter-runtime.XXXXXX")
trap 'rm -rf "$adapter_temp"' EXIT
unset PYTHONPATH PYTHONHOME
python3 -m venv "$adapter_temp/bootstrap"
"$adapter_temp/bootstrap/bin/python" -m pip --quiet install 'uv==0.12.23'
export UV_PROJECT_ENVIRONMENT="$adapter_temp/runtime"
"$adapter_temp/bootstrap/bin/uv" sync --project "$adapter_root" --frozen --no-dev --python 3.12
case "$1" in
  foundation)
    "$adapter_temp/runtime/bin/python" "$adapter_root/foundation_release.py"
    ;;
  configure)
    "$adapter_temp/runtime/bin/python" "$adapter_root/stage_configuration.py" \
      --publication "$ADP_TOOLS_ADAPTER_PUBLICATION_FILE" --output "$ADP_TOOLS_ADAPTER_CONFIG_FILE"
    ;;
  receipt)
    "$adapter_temp/runtime/bin/python" "$adapter_root/release_evidence.py" --output "$ADP_TOOLS_ADAPTER_RELEASE_DIR"
    ;;
  *) "$adapter_temp/runtime/bin/python" "$adapter_root/deploy.py" "$1" ;;
esac
